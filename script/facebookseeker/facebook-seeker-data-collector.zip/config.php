<?php
$config['APP_ID']            =   'YOUR APP ID' ;  
$config['APP_SECRET']        =   'YOUR APP SECRET';  
$config['REDIRECT_URL']      =   'http://www.yourdomain.com';
$config['APP_DIRECTORY']     =   'facebookseeker';
?>
