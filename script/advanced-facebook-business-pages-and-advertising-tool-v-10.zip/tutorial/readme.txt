To Install just extract the script folder to your hosting root folder

1. Then create a database and import database in the database folder

2. Open configdata.php
and edit the database connection 
3. edit the access token
4. open your domain url and enjoy




Thanks For purchasing My script

The script can also be installed for you by our proffession at just 7$

You can get custom scripts or script customization just contact us on gambanet2015@gmail.com

Thanks AGain
