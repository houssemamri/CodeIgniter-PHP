<div class="container">
<nav class="navbar navbar-default">
  <div class="container-fluid">
    <div class="navbar-header">
      <a class="navbar-brand" href="#">RSS/XML to Social Poster</a>
    </div>
    <ul class="nav navbar-nav pull-right">
      <li class="active"><a href="#">Welcome <?php echo $_SESSION['username']; ?></a></li>
      
      <li><a href="logout.php">Logout</a></li> 
    </ul>
  </div>
</nav>