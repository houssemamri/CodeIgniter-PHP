<footer class="footer">
      <div class="container">
<br>
        <p class="text-muted">Facebook Emails Scraper By <a href="http://bizyangu.com">Gambanetwork Developers</a> complies to facebook terms for its scrapes public posts in its platform Copyright 2016  All Rights Reserved.</p>
      </div>
    </footer>
	
	
<link href="https://cdn.datatables.net/responsive/2.0.2/css/responsive.bootstrap.min.css" rel="stylesheet" id="bootstrap-css">
<link href="https://cdn.datatables.net/1.10.11/css/dataTables.bootstrap.min.css" rel="stylesheet" id="bootstrap-css">
    
     <!--Scripts-->
    <script src="theme/jquery-1.10.2.min.js"></script>
    <script src="theme/bootstrap.min.js"></script>

<script src="http://ajax.googleapis.com/ajax/libs/jquery/1.9.1/jquery.min.js"></script>
<script src="http://getbootstrap.com/dist/js/bootstrap.min.js"></script>
<script src="https://cdn.datatables.net/1.10.11/js/jquery.dataTables.min.js"></script>
<script src="https://cdn.datatables.net/1.10.11/js/dataTables.bootstrap.min.js"></script>
<script src="https://cdn.datatables.net/responsive/2.0.2/js/dataTables.responsive.min.js"></script>
<script src="https://cdn.datatables.net/responsive/2.0.2/js/responsive.bootstrap.min.js"></script>