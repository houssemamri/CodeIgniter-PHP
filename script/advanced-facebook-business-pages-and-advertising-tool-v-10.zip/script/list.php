<?php


include("inc/head1.php");
?>




<div class="table-responsive">          
 <table class="table table-bordered" id="example">
    <thead>
      <tr>
        
        
		
        <td>Page Name</td>
		<td>Page Phones</td>
		<td>Page Emails</td>
		
		<td>Page Likes</td>
		<td>Page Link</td>
		
      </tr>
    </thead>
    <tbody>
	<?php
$useremail->emails();

?>

    </tbody></table>

</div></div></div>

<?php include("inc/foot.php"); ?>