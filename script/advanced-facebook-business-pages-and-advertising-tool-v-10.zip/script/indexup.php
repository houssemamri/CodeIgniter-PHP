<?php


include("inc/head.php");
?>
  
  <div class="col-sm-12">
    
	<div class="col-sm-2">
	<script async src="//pagead2.googlesyndication.com/pagead/js/adsbygoogle.js"></script>
<!-- menubar -->
<ins class="adsbygoogle"
     style="display:block"
     data-ad-client="ca-pub-4084759855585302"
     data-ad-slot="2452790076"
     data-ad-format="auto"></ins>
<script>
(adsbygoogle = window.adsbygoogle || []).push({});
</script>
	</div>
	<div class="col-sm-8" >
<h1 style="text-align:center;"> Latest Searched Results</h1>
		
           
							

							
<div class="table-responsive">          
 <table class="table table-bordered" id="example">
    <thead>
      <tr>
        
        
		
		<td>Page Picture</td>
        <td>Page Name</td>
		<td>Page category</td><td>Page Phones</td>
		<td>Page Emails</td><td>Page website Link</td>
		<td>Page Likes</td><td>Page Link</td>
		
		<td>About Page</td>
      </tr>
    </thead>
    <tbody>
	<?php
	$useremail = new Users();
$useremail->emails1();

?>

    </tbody></table>
                        </div>
						</div>
						<div class="col-sm-2">
						<script async src="//pagead2.googlesyndication.com/pagead/js/adsbygoogle.js"></script>
<!-- menubar -->
<ins class="adsbygoogle"
     style="display:block"
     data-ad-client="ca-pub-4084759855585302"
     data-ad-slot="2452790076"
     data-ad-format="auto"></ins>
<script>
(adsbygoogle = window.adsbygoogle || []).push({});
</script>
						</div>
						
						
						</div>
						
				<?php include("inc/foot.php"); ?>
						