<?php

include("inc/head1.php");
include_once("includes/functions.php");
$user = new Users(); 
 $user->clear();
 
?>
