<?php
session_start();


$dbServer = 'localhost'; //Define database server host
$dbUsername = 'root'; //Define database username
$dbPassword = 'mysql'; //Define database password
$dbName = 'login'; //Define database name



//application address
define('DIR','http://mydomain.com/');
define('SITEEMAIL','apps@bizyangu.com');



//edit  This you can get it in app.bizyangu.com
$access_token='My facebook access token';
		
		

?>

